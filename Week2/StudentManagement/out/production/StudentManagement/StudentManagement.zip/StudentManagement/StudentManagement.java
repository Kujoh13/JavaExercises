import java.util.ArrayList;

public class StudentManagement {

    private Student[] students = new Student[100];
    private int index = -1;

    /**
     * check if two students are in the same group.
     */
    public static boolean sameGroup(Student s1, Student s2) {
        return s1.get_group().equals(s2.get_group());
    }

    /**
     * add a student to the students array
     */
    public void addStudent(Student newStudent) {
        students[++index] = newStudent;
    }

    /**
     * remove a student from the array
     */
    public void removeStudent(String id) {
        int pos = 0;
        for (int i = 0; i <= index; i++) {
            if (students[i].get_id().equals(id)) {
                pos = i;
                break;
            }
        }
        for (int i = pos; i < index; i++) {
            students[i] = students[i + 1];
        }
        index--;
    }

    /**
     * return a string of students' info in group order
     */
    public String studentsByGroup() {
        String res = new String();
        String[] temp = new String[100];
        int ind = -1;
        for (int i = 0; i <= index; i++) {
            boolean ok = true;
            for (int j = 0; j <= ind; j++) {
                if (students[i].get_group().equals(temp[j])) {
                    ok = false;
                    break;
                }
            }
            if (ok == false) continue;
            res += students[i].get_group() + "\n";
            temp[++ind] = students[i].get_group();
            for (int j = i; j <= index; j++) {
                if (students[j].get_group().equals(students[i].get_group())) {
                    res += students[j].getInfo() + "\n";
                }
            }
        }
        return res;
    }

}
