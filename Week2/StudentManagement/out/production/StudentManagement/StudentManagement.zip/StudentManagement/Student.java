public class Student {

    private String name;
    private String id;
    private String group;
    private String email;

    /**
     * initialize a student object.
     */
    public Student() {
        name = "Student";
        id = "000";
        group = "K62CB";
        email = "uet@vnu.edu.vn";
    }

    /**
     * initialize a student object with name, id and email.
     */
    public Student(String name, String id, String email) {
        this.name = name;
        this.id = id;
        this.email = email;
        group = "K62CB";
    }

    /**
     * initialize a student with another student.
     */
    public Student(Student S) {
        name = S.get_name();
        id = S.get_id();
        group = S.get_group();
        email = S.get_email();
    }

    /**
     * return name, id, group and email.
     */
    public String getInfo() {
        return name + " - " + id + " - " + group + " - " + email;
    }

    public String get_name() {
        return name;
    }

    public String get_id() {
        return id;
    }

    public String get_group() {
        return group;
    }

    public String get_email() {
        return email;
    }

    public void set_name(String name) {
        this.name = name;
    }

    public void set_id(String id) {
        this.id = id;
    }

    public void set_group(String group) {
        this.group = group;
    }

    public void set_email(String email) {
        this.email = email;
    }


}
